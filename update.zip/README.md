# AAS Update v1.0.1

## Novidades nesta versão:
- ✅ Sistema de atualização automática via GitHub
- ✅ Interface gráfica aprimorada
- ✅ Melhor estabilidade do sistema

## Arquivos modificados:
- `src/system/updater.py` - Nova classe GitHubUpdater
- `gui/desktop/backends/qml/UpdateView.qml` - Interface de atualização
- `config/config.json` - Configurações atualizadas

## Como instalar:
Este update será aplicado automaticamente pelo sistema.

---
*Gerado automaticamente em 20/01/2026*